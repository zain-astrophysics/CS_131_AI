# Genetic algorithm 

** Description **
This Python project uses genetic algorithm to fill the backpack to make it valuable as possible without exceeding the maximum weight of 250.

** Package Information **
1. random: This package allowed us to obtain random integers between 0 and 1

2. matplotlib: This package allowed us to plot the generations and best fitness value. 

*** Running the Python script ***

1. The user should open the Genetic_algorithm.py and run the code

2. The user will be prompted to enter two choices: 

     1. Parent population size   
     2. Number of Generation size 


3. The code will run and proceed and will produce useful statistics. 

